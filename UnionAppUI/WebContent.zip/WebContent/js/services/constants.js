app.service('constant', function () {

	this.bid ="123";

	// login page

	this.email_placeHolder = "email"; 
	this.password_placeHolder ="password";
	this.forget_password = "Forgot Password";
	this.login_button = "Login";
	this.footer_title = "powered by unik-apps.com"
	this.title = "WFS KLUBBEN ADMIN PANEL";

	// Meeting Dashboard Page 

	this.Date = "Date";
	this.Time = "Time";
	this.Place = "Place";
	this.Comming ="Comming";
	this.NotComming ="Not Comming";
	this.did_not_answer = "Did Not Answer";
	this.Actions = "Actions";
	this.Edit = "Edit";
	this.Live ="Live";
	this.Offline = "Offline";
	this.Delete = "Delete";
	this.addNewMeeting = "Add New Meeting";
	this.Next_Meeting ="Next Meeting";


	// new meeting page

	this.Subject ="Subject";
	this.Details ="Details";


	// edit Activitity Page

	this.editActivity = "Edit Activity";
	this.saveActivity  = "Save Activity";
	this.newActivity  = "New Activity";
	this.addNewActivity = "Add New Activity";
});